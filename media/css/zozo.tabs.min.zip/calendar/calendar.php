<div class="LMODULEW">
<div class="col-md-3">

            <div class="dzscalendar skin-aurora" id="traurora" style="margin:0px auto;">
                <div class="events">
                    <div class="event-tobe" data-repeat="everymonth" data-day="09" data-tag="important">
                        <div class="CCWBG">
                        <div class="CERCICO">
                            <h5>FS Metro theme based<br />interface</h5>
                            <span class="label">Dato</span> 09-8-2012 at 6PM<br/>
                            <span class="label">Lokasjon</span> Holterveien 4 B. 1448 Drøbak<br/>
                            <br/>Ny brukergrensesnitt med custome design er under veis.
                            <div class="CCENEWSREADM"><a class="CCENEWSREADMICON" href="#">Les mer ...</a></div>
                        </div>
                    </div></div>
                    <div class="event-tobe" data-repeat="everymonth" data-day="22" data-tag="important">
                        <div class="CCWBG">
                        <div class="CERCICO">
                            <h5>Payam har bursdag :)</h5>
                            <span class="label">Dato</span> 22-8-2012 at 6PM<br/>
                            <span class="label">Lokasjon</span> Holterveien 4 B. 1448 Drøbak<br/>
                            <br/>Skal feires med masse god mat og digg deser :)
                        </div>
                    </div></div>
                    <div class="event-tobe" data-repeat="everymonth" data-day="10"></div>

                </div>
            </div>
           
        </div>
</div>